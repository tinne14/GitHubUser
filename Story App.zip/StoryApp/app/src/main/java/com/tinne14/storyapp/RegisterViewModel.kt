package com.tinne14.storyapp

import android.app.Application
import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tinne14.storyapp.data.RegisterResult
import kotlinx.coroutines.launch

class RegisterViewModel(private val application: Application) : ViewModel(){
    private val mRepository: Repository = Repository(application)
    val registerResponse: LiveData<RegisterResult> = mRepository.registerResponse

    fun postRegister(name: String, email: String, password: String, context: Context){
        viewModelScope.launch {
            mRepository.postRegister(name, email, password, context)
        }
    }
}