package com.tinne14.storyapp

import android.app.Application
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.tinne14.storyapp.data.ApiConfig
import com.tinne14.storyapp.data.ApiService
import com.tinne14.storyapp.data.RegisterResult
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Repository(private val apiService: Application) {

    private val TAG = "Repository"

    private val _registerResponse = MutableLiveData<RegisterResult>()
    val registerResponse: LiveData<RegisterResult> = _registerResponse

    fun postRegister(name: String, email: String, password: String, context: Context) {
        val client = ApiConfig.getApiService().postRegister(name, email, password)
        client.enqueue(object: Callback<RegisterResult> {
            override fun onResponse(
                call: Call<RegisterResult>,
                response: Response<RegisterResult>
            ) {
                if (response.isSuccessful){
                    _registerResponse.value = response.body()
                    Toast.makeText(context ,response.body()?.message, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context ,response.errorBody().toString(), Toast.LENGTH_LONG).show()
                    Log.e(TAG, "Eror: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<RegisterResult>, t: Throwable) {
                Toast.makeText(context ,t.message.toString(), Toast.LENGTH_SHORT).show()
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }

}